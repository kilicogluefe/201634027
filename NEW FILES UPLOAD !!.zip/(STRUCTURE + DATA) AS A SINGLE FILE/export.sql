CREATE DATABASE  IF NOT EXISTS `ekmusic_company` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `EK201634027music_company`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: oaekmusic_company
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `album` (
  `album_id` int(11) NOT NULL AUTO_INCREMENT,
  `album_name` varchar(45) DEFAULT NULL,
  `singer_singer_id` int(11) NOT NULL,
  PRIMARY KEY (`album_id`),
  KEY `fk_album_singer1_idx` (`singer_singer_id`),
  CONSTRAINT `fk_album_singer1` FOREIGN KEY (`singer_singer_id`) REFERENCES `singer` (`singer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,'KORKU',1),(2,'SPOR',2),(3,'HIZLI',3),(4,'SAKİN',4),(5,'BOKS',5);
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'SPOR'),(2,'KORKU'),(3,'HIZLI'),(4,'YAVAS'),(5,'SAKİN');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_1`
--

DROP TABLE IF EXISTS `category_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `category_1` (
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_1`
--

LOCK TABLES `category_1` WRITE;
/*!40000 ALTER TABLE `category_1` DISABLE KEYS */;
INSERT INTO `category_1` VALUES (1,'KORKU'),(2,'BOKS'),(3,'HIZLI'),(4,'YAVAS'),(5,'BOKS');
/*!40000 ALTER TABLE `category_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `music type`
--

DROP TABLE IF EXISTS `music type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `music type` (
  `music type_id` int(11) NOT NULL AUTO_INCREMENT,
  `music type_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`music type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music type`
--

LOCK TABLES `music type` WRITE;
/*!40000 ALTER TABLE `music type` DISABLE KEYS */;
INSERT INTO `music type` VALUES (1,'ROCK'),(2,'HIZLI'),(3,'BOKS'),(4,'SAKİN'),(5,'EGLENCE');
/*!40000 ALTER TABLE `music type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist`
--

DROP TABLE IF EXISTS `playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `playlist` (
  `playlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `playlist_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`playlist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist`
--

LOCK TABLES `playlist` WRITE;
/*!40000 ALTER TABLE `playlist` DISABLE KEYS */;
INSERT INTO `playlist` VALUES (1,'EGLENCE'),(2,'DRAM'),(3,'HIZLI'),(4,'SAKİN'),(5,'SPOR');
/*!40000 ALTER TABLE `playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_has_category`
--

DROP TABLE IF EXISTS `playlist_has_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `playlist_has_category` (
  `playlist_playlist_id` int(11) NOT NULL,
  `category_category_id` int(11) NOT NULL,
  PRIMARY KEY (`playlist_playlist_id`,`category_category_id`),
  KEY `fk_playlist_has_category_category1_idx` (`category_category_id`),
  KEY `fk_playlist_has_category_playlist1_idx` (`playlist_playlist_id`),
  CONSTRAINT `fk_playlist_has_category_category1` FOREIGN KEY (`category_category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `fk_playlist_has_category_playlist1` FOREIGN KEY (`playlist_playlist_id`) REFERENCES `playlist` (`playlist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_has_category`
--

LOCK TABLES `playlist_has_category` WRITE;
/*!40000 ALTER TABLE `playlist_has_category` DISABLE KEYS */;
INSERT INTO `playlist_has_category` VALUES (1,1),(2,2),(3,3),(4,4),(5,5);
/*!40000 ALTER TABLE `playlist_has_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producer`
--

DROP TABLE IF EXISTS `producer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `producer` (
  `producer_id` int(11) NOT NULL AUTO_INCREMENT,
  `producer_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`producer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producer`
--

LOCK TABLES `producer` WRITE;
/*!40000 ALTER TABLE `producer` DISABLE KEYS */;
INSERT INTO `producer` VALUES (1,'NETD'),(2,'PAINT'),(3,'ZUHAL'),(4,'PLAK'),(5,'DART');
/*!40000 ALTER TABLE `producer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `singer`
--

DROP TABLE IF EXISTS `singer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `singer` (
  `singer_id` int(11) NOT NULL AUTO_INCREMENT,
  `singer_name` varchar(45) DEFAULT NULL,
  `producer_producer_id` int(11) NOT NULL,
  PRIMARY KEY (`singer_id`),
  KEY `fk_singer_producer1_idx` (`producer_producer_id`),
  CONSTRAINT `fk_singer_producer1` FOREIGN KEY (`producer_producer_id`) REFERENCES `producer` (`producer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `singer`
--

LOCK TABLES `singer` WRITE;
/*!40000 ALTER TABLE `singer` DISABLE KEYS */;
INSERT INTO `singer` VALUES (1,'EFE',1),(2,'ONUR',2),(3,'ALİ',3),(4,'VELİ',4),(5,'TOYGUN',5);
/*!40000 ALTER TABLE `singer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `singer_has_song`
--

DROP TABLE IF EXISTS `singer_has_song`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `singer_has_song` (
  `singer_singer_id` int(11) NOT NULL,
  `song_song_id` int(11) NOT NULL,
  PRIMARY KEY (`singer_singer_id`,`song_song_id`),
  KEY `fk_singer_has_song_song1_idx` (`song_song_id`),
  KEY `fk_singer_has_song_singer1_idx` (`singer_singer_id`),
  CONSTRAINT `fk_singer_has_song_singer1` FOREIGN KEY (`singer_singer_id`) REFERENCES `singer` (`singer_id`),
  CONSTRAINT `fk_singer_has_song_song1` FOREIGN KEY (`song_song_id`) REFERENCES `song` (`song_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `singer_has_song`
--

LOCK TABLES `singer_has_song` WRITE;
/*!40000 ALTER TABLE `singer_has_song` DISABLE KEYS */;
INSERT INTO `singer_has_song` VALUES (1,1),(2,2),(3,3),(4,4),(5,5);
/*!40000 ALTER TABLE `singer_has_song` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `song`
--

DROP TABLE IF EXISTS `song`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `song` (
  `song_id` int(11) NOT NULL AUTO_INCREMENT,
  `song_name` varchar(45) DEFAULT NULL,
  `album_album_id` int(11) NOT NULL,
  `music type_music type_id` int(11) NOT NULL,
  PRIMARY KEY (`song_id`),
  KEY `fk_song_album_idx` (`album_album_id`),
  KEY `fk_song_music type1_idx` (`music type_music type_id`),
  CONSTRAINT `fk_song_album` FOREIGN KEY (`album_album_id`) REFERENCES `album` (`album_id`),
  CONSTRAINT `fk_song_music type1` FOREIGN KEY (`music type_music type_id`) REFERENCES `music type` (`music type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `song`
--

LOCK TABLES `song` WRITE;
/*!40000 ALTER TABLE `song` DISABLE KEYS */;
INSERT INTO `song` VALUES (1,'dert',1,1),(2,'eglence',2,2),(3,'sokak',3,3),(4,'bulut',4,4),(5,'mavi',5,5);
/*!40000 ALTER TABLE `song` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `song_has_category`
--

DROP TABLE IF EXISTS `song_has_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `song_has_category` (
  `song_song_id` int(11) NOT NULL,
  `category_category_id` int(11) NOT NULL,
  PRIMARY KEY (`song_song_id`,`category_category_id`),
  KEY `fk_song_has_category_category1_idx` (`category_category_id`),
  KEY `fk_song_has_category_song1_idx` (`song_song_id`),
  CONSTRAINT `fk_song_has_category_category1` FOREIGN KEY (`category_category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `fk_song_has_category_song1` FOREIGN KEY (`song_song_id`) REFERENCES `song` (`song_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `song_has_category`
--

LOCK TABLES `song_has_category` WRITE;
/*!40000 ALTER TABLE `song_has_category` DISABLE KEYS */;
INSERT INTO `song_has_category` VALUES (1,1),(2,2),(3,3),(4,4),(5,5);
/*!40000 ALTER TABLE `song_has_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `song_has_playlist`
--

DROP TABLE IF EXISTS `song_has_playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `song_has_playlist` (
  `song_song_id` int(11) NOT NULL,
  `playlist_playlist_id` int(11) NOT NULL,
  PRIMARY KEY (`song_song_id`,`playlist_playlist_id`),
  KEY `fk_song_has_playlist_playlist1_idx` (`playlist_playlist_id`),
  KEY `fk_song_has_playlist_song1_idx` (`song_song_id`),
  CONSTRAINT `fk_song_has_playlist_playlist1` FOREIGN KEY (`playlist_playlist_id`) REFERENCES `playlist` (`playlist_id`),
  CONSTRAINT `fk_song_has_playlist_song1` FOREIGN KEY (`song_song_id`) REFERENCES `song` (`song_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `song_has_playlist`
--

LOCK TABLES `song_has_playlist` WRITE;
/*!40000 ALTER TABLE `song_has_playlist` DISABLE KEYS */;
INSERT INTO `song_has_playlist` VALUES (1,1),(2,2),(3,3),(4,4),(5,5);
/*!40000 ALTER TABLE `song_has_playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `username` varchar(16) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-03  2:03:58
